# need to be modified

import sys
import json
import pdb
import glob
from tqdm import tqdm
import os
import csv
from openpyxl import Workbook
from pathlib import Path
#from text_generation import Client
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

tokenizer = AutoTokenizer.from_pretrained("path/to/vicuna-13b-v1.5")
model = AutoModelForCausalLM.from_pretrained("path/to/vicuna-13b-v1.5", device_map="auto")
# PORT = sys.argv[2]

ALL_TASKS = ['text_vqa', 'visual_spatial_reasoning', 'snli_ve_classification', 'cifar_10', 'cifar_100','mnist','pope_adv','pope_pop','pope_rand']

# client = Client(f"http://127.0.0.1:{PORT}")

SYS_PROMPT ="A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions."

STOP_TOKENS = ['Human:','### Human:','### Human ']

METRICS = ['llm_eval']

def print_latex(all_results):
    name_str = ' & '.join([r[0] for r in all_results[:-3]])
    name_str += ' & pope & MMAvg'
    scores = [r[1]['llm_eval'] * 100 for r in all_results]
    scores_str = ' & '.join([str(round(score, 2)) for score in scores[:-3]])
    pope_score = np.mean(scores[-3:])
    avg_score = np.mean(scores[:-3] + [pope_score])
    scores_str += f' & {round(pope_score, 2)} & {round(avg_score, 2)}'
    print(name_str)
    print(scores_str)

def entailment_score(targets, responses, prompts):
    ent_score = 0.0
    i = 0
    model_acc = []
    for target, res, prompt in tqdm(zip(targets, responses, prompts)):
        # pdb.set_trace()
        clean_prompt = prompt.replace("A chat between a curious human and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the human's questions. USER: ",'').strip()
        clean_prompt = clean_prompt.replace('ASSISTANT:','').strip()
        clean_prompt = clean_prompt.replace('<image>','').strip()
        try:
            prompt_raw = f"{SYS_PROMPT} USER: Decide if the prediction is correct given the question and the answer.\nQuestions: {clean_prompt}\nAnswer: {target}\nPrediction: {res}\nYour response should only be Yes or No. ASSISTANT:"
            input_ids = tokenizer(prompt_raw, return_tensors="pt").input_ids.cuda()
            output = model.generate(input_ids, max_new_tokens=5, stop_sequences=STOP_TOKENS)
            output = tokenizer.decode(output[0], skip_special_tokens=True)
        except:
            print(f'warning invalid target: {target} response: {res} prompt: {prompt}')
            continue
        if 'yes' in output.lower():
            ent_score += 1.0
            model_acc.append(1)
        else:
            model_acc.append(0)
        
    return ent_score/len(targets)            

def evaluate(input_file):
    predictions = []
    references = []
    prompts = []
    with open(input_file,'r') as fin:
        print(input_file)
        task_name = input_file.split('/')[-1]
        task_name = task_name.replace('.jsonl','')
        print(f'#### now evaluating {task_name}')
        for line in fin:
            line = json.loads(line)
            predictions.append(line['predict'])
            references.append(line['target'])
            prompts.append(line['prompt'])
        result = {'llm_eval': entailment_score(references, predictions, prompts)}
    return result, task_name

if __name__ == '__main__':
    print(len(sys.argv))
    print(sys.argv[1])
    model_path = Path(sys.argv[1])
    result_folder = model_path / 'results' / "full"
    performance_folder = model_path / 'performance' / "full"
  
    performance_folder.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    # Define rows
    dataset_names_row = []
    metric_names_row = []
    metric_values_row = []
    all_results = []
    performance_list = []
    for task_name in ALL_TASKS:
        file_path = f'{result_folder}/{task_name}.jsonl'
        if not os.path.exists(file_path):
            print(f"the result file: {file_path} does not exist, will skip {task_name} !!!!!!!!")
            continue
        try:
            results, _ = evaluate(file_path)
        except Exception as e:
            print(str(e))
            print(f"{task_name} failed !!!!!!!!!")
            performance_list.append([None]*len(METRICS))
            continue
        print(results)
        
        performance_list.append([results.get(_metric,None) for _metric in METRICS ])
        dataset_names_row.extend([task_name] * len(results))
        for metric_name in METRICS:
            if metric_name in results:
                metric_value = results[metric_name]
                metric_names_row.append(metric_name)
                metric_values_row.append(metric_value)
        all_results.append((task_name, results))
    
    print_latex(all_results)
        
    ws.append(dataset_names_row)
    ws.append(metric_names_row)
    ws.append(metric_values_row)
    
    # Merge dataset name cells
    col_index = 1
    for dataset_dict in all_results:
        dataset_name, metrics = dataset_dict
        ws.merge_cells(start_row=1, start_column=col_index, end_row=1, end_column=col_index+len(metrics)-1)
        col_index += len(metrics)

    wb.save(f'{performance_folder}/llm_performance.xlsx')
    json.dump(performance_list, open(f'{performance_folder}/llm_performance.json','w'))