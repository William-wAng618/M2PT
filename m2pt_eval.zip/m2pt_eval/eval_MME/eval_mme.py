# %%
import json
import glob
import os
import argparse
import pdb

# %%
parser = argparse.ArgumentParser()
parser.add_argument('--path',default="/path/to/MME_Answer_file", type=str)
parser.add_argument('--output-path',default="/path/to/MME_Results", type=str)
parser.add_argument('--template-path',default="/path/to/MME/eval_tool/Your_Results", type=str)
args = parser.parse_args()
os.makedirs(args.output_path, exist_ok=True)

# %%
result_folder_path = args.path
ls_pred = glob.glob(result_folder_path + '/*.jsonl')
ls_gt = glob.glob(args.template_path + '/*.txt')

# %%
print(result_folder_path)
ls_basenames = [os.path.basename(x).split('.')[0] for x in ls_pred]
print("tasks:", ls_basenames)
# %%
for basename in ls_basenames:
    f = open(result_folder_path + '/' + basename + '.jsonl', 'r')
    data_jsonl = f.readlines()
    f.close()
    f = open(os.path.join(args.template_path, basename + '.txt'),
             'r')
    data_text = f.readlines()
    f.close()
    # print(len(data_text), len(data_jsonl))

    for i in range(len(data_text)):
        if basename == 'celebrity':
            a=1
        predict = json.loads(data_jsonl[i])['predict']
        # pdb.set_trace()
        if 'yes' in predict.lower():
            predict = 'Yes'
        elif 'no' in predict.lower():
            predict = 'No'
        else:
            # print(basename, i, predict)
            predict = predict.replace('\n', ' ')
        data_text[i] = data_text[i][:-1] + '\t' + predict + '\n'
    with open(os.path.join(args.output_path, basename + '.txt'),
              'w') as f:
        print(os.path.join(args.output_path, basename + '.txt'))
        f.writelines(data_text)


