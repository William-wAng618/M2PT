#!/bin/bash
answersfile="/path/to/playground/data/eval/MME/answers/0528_eval_0515_pt_eval"
templatefile="/path/to/playground/data/eval/MME/eval_tool/Your_Results"
caloutfile="/path/to/playground/data/eval/MME/0528_eval_0515_pt_eval"

python -m M2PT.eval.model_vqa_loader_PT_mme \
    --model-path /path/to/checkpoints/xxx/checkpoint-18000 \
    --PT-path /path/to/checkpoints/xxx \
    --question-file llava_mme.jsonl \
    --image-folder /path/to/playground/data/eval/MME/MME_Benchmark_release_version \
    --answers-file  $answersfile\
    --temperature 0.2 \
    --max_new_tokens 128 \
    --conv-mode vicuna_v1 \

python eval_mme.py --path $answersfile --output-path $caloutfile --template-path $templatefile
python calculation.py --results_dir $caloutfile
